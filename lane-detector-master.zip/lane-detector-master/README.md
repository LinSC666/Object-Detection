# Lane Detector Tutorial
Lane detection using Canny Detector and Hough Transform

# Usage

```
python lane_detector.py
```
